export const ActorList = [
  {
    name: "Rami Malek",
    img_src:
      "https://www.imdb.com/name/nm1785339/mediaviewer/rm885121280?ref_=nm_ov_ph"
  },
  {
    name: "Christian Bale",
    img_src:
      "https://www.imdb.com/name/nm0000288/mediaviewer/rm3114052352?ref_=nm_ov_ph"
  },
  {
    name: "Bradley Cooper",
    img_src:
      "https://www.google.com/url?sa=i&source=images&cd=&cad=rja&uact=8&ved=2ahUKEwiiz7mLy7PhAhV8WhUIHZYNAHUQjRx6BAgBEAU&url=https%3A%2F%2Fwww.filmweb.pl%2Fperson%2FBradley%2BCooper-57074&psig=AOvVaw3pdA3JiRvJU9foPF30BA58&ust=1554369321268359"
  },
  {
    name: "Willem Dafoe",
    img_src:
      "https://pl.wikipedia.org/wiki/Plik:Willem_Dafoe_2014_(cropped).jpg"
  }
];
